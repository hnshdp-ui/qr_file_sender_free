python-qrcode 8.2, BSD license. Sources bundled unchanged.
https://github.com/lincolnloop/python-qrcode
Only QR matrix generation is used; Pillow and PyPNG are not required.
